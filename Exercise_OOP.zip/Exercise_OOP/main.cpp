#include <iostream>
#include "Engine.h"
#include "Controller.h"
#include "Car.h"
#include "FuelTank.h"
#include "Battery.h"
#include "HMI.h"
using namespace std;

int main(){
    Car AudiCar;
    AudiCar.getController(AudiCar, ::L1, 50);

//    cout << "Gear real : " << gear;
    FuelTank tank1;
    tank1.setFuel(1000);
    tank1.consumeFuel(AudiCar, tank1.getFuel());

    Battery battery;
    battery.setBattery(500);
    battery.chargeEnergy(AudiCar, battery.getEnergy());

    HMI hmi;
    hmi.showInfor(AudiCar);

    AudiCar.controlLight()->turnLight("on");


    return 0;
}



#include "FuelTank.h"
#include "Car.h"
#include <iostream>
using namespace std;

FuelTank::FuelTank()
{
    //ctor
}

FuelTank::~FuelTank()
{
    //dtor
}

void FuelTank::setFuel(int setF)
{
    if (setF > 75000 && setF < 0) cout << "Error" << endl;
    else fuel = setF;
}

int FuelTank::getFuel()
{
    cout << " " << endl;
    cout << "----Fuel tank ----" << endl;
    cout << "Fuel tank is containing " << fuel << " ml" << endl;
    return fuel;
}

void FuelTank::consumeFuel(Car& car, int fuel)
{
    Gear currentgear = car.getInforGear;
    int currentpercent = car.getInforPercent;
    if (currentgear == ::D)
    {
        if (fuel >= currentpercent * 10)
        {
            fuel = fuel - currentpercent * 10;
            car.getInforPercentChanged = car.getInforPercent;
        }
        else
        {
            cout << "Lack of fuel " << currentpercent * 10 - fuel << " to get the target" << endl;
            cout << "Just can go " << fuel/10 << " m" << endl;
            car.getInforPercentChanged = fuel/10;
            fuel = 0;


        }

    }
    if (currentgear == ::L2)
    {
        if (fuel >= currentpercent * 20)
        {
            {
                fuel = fuel - currentpercent * 20;
                car.getInforPercentChanged = car.getInforPercent;
            }
        }
        else
        {
            cout << "Lack of fuel " << currentpercent * 20 - fuel << " to get the target" << endl;
            cout << "Just can go " << fuel/20 << " m" << endl;
            car.getInforPercentChanged = fuel/20;
            fuel = 0;

        }

    }
    if (currentgear == ::L1 || currentgear == ::R)
    {
        if (fuel >= currentpercent * 30)
        {
            {
                fuel = fuel - currentpercent * 30;
                car.getInforPercentChanged = car.getInforPercent;
            }
        }
        else
        {
            cout << "Lack of fuel " << currentpercent * 30 - fuel << " to get the target" << endl;
            cout << "Just can go " << fuel/30 << " m" << endl;
            car.getInforPercentChanged = fuel/30;
            fuel = 0;

        }

    }
    car.getInforFuel = fuel;
    cout << "Fuel: " << fuel << endl;
}

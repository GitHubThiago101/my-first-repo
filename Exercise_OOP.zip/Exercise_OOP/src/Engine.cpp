#include "Engine.h"
#include "Controller.h"
#include "Car.h"
#include <iostream>
#include <string>
using namespace std;

Engine::Engine()
{
    //ctor
}

Engine::~Engine()
{
    //dtor
}

Engine::Engine(const Engine& other)
{
    //copy ctor
}

Engine& Engine::operator=(const Engine& rhs)
{
    if (this == &rhs) return *this; // handle self assignment
    //assignment operator
    return *this;
}

void Engine::setDelegate(EngineDelegate& del){
    delegateCar = &del;
}

void Engine::didChangeGear(Gear g){
    currentG = g;
    cout << "currentG " << currentG << endl;

}

void Engine::didStepOnAccelerator(int percent){
    if (percent >= 1 && percent <=100)
    {
        if (currentG == ::N)
        {
            stateGear = "Stop";
            cout << stateGear << endl;
        }
        else if (currentG == ::D)
        {
            stateGear = "Go forward ";
            cout << stateGear << percent << " m" << endl;
        }
        else if (currentG == ::R)
        {
            stateGear = "Go back ";
            cout << stateGear << percent << " m" << endl;
        }
        else if (currentG == ::L1)
        {
            stateGear = "Go L1 mode ";
            cout << stateGear << percent << " m" << endl;
        }
        else if (currentG == ::L2)
        {
            stateGear = "Go L2 mode ";
            cout << stateGear << percent << " m" << endl;
        }
        else cout << "ERROR";
    }
    delegateCar->runThisCar(currentG, percent);

}


#include "Battery.h"
#include "Car.h"
#include <iostream>
using namespace std;

Battery::Battery()
{
    //ctor
}

Battery::~Battery()
{
    //dtor
}

void Battery::setBattery(int setB)
{
    if (setB > 1000 && setB < 0) cout << "Error" << endl;
    else energy = setB;
}

int Battery::getEnergy()
{
    cout << " " << endl;
    cout << "----Battery----" << endl;
    cout << "Battery is containing : " << energy << " mAh" << endl;
    return energy;
}

void Battery::chargeEnergy(Car& car, int energy)
{
//       Gear currentgear = car.gear;
    int currentpercent;
    if (car.getInforPercent == car.getInforPercentChanged)
    {
        currentpercent = car.getInforPercent;
    }
    else currentpercent = car.getInforPercentChanged;
    energy += currentpercent;
    cout << "Energy charged : " << energy << endl;
    car.getInforBattery = energy;
    getInforEnergy = energy;
}

#include "Controller.h"
#include "Engine.h"
#include "Car.h"
#include <iostream>
using namespace std;


Controller::Controller()
{

}

Controller::~Controller()
{
    //dtor
}

Controller::Controller(const Controller& other)
{
    //copy ctor
}

Controller& Controller::operator=(const Controller& rhs)
{
    if (this == &rhs) return *this; // handle self assignment
    //assignment operator
    return *this;
}

void Controller::setDelegate(ControllerDelegate& g){
    delegate = &g;
}
void Controller::changeGear(Gear g){
    gear = g;
    delegate->didChangeGear(gear);
}

void Controller::stepOnAccelerator(int per){
    percent = per;
    delegate->didStepOnAccelerator(percent);
}


void Controller::turnLight(string str){
    cout << " " << endl;
    cout << "----Control light----" << endl;
    cout << "Light is " << str << endl;
    if (str == "on") cout << "What I found " << endl;
}

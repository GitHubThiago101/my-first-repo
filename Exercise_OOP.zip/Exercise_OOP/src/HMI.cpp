#include "HMI.h"
#include "Car.h"
#include <iostream>
using namespace std;

HMI::HMI()
{
    //ctor
}

HMI::~HMI()
{
    //dtor
}

void HMI::showInfor(Car& car)
{
    cout << " " << endl;
    cout << "----Information of Car----" << endl;
    cout << "Fuel : " << car.getInforFuel << endl;
    cout << "Battery : " << car.getInforBattery << endl;
    cout << "Gear : " << car.getInforGear << endl;

}

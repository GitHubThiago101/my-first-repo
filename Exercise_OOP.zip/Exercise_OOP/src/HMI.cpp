#include "HMI.h"
#include "Car.h"
#include <iostream>
using namespace std;

HMI::HMI()
{
    //ctor
}

HMI::~HMI()
{
    //dtor
}

void HMI::showInfor()
{
//    cout << " " << endl;
//    cout << "----Information of Car----" << endl;
//    cout << "Fuel : " << fuel << endl;
//    cout << "Battery : " << battery << endl;
//    cout << "Gear : " <<  << endl;

}

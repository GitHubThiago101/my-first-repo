#ifndef HMI_H
#define HMI_H
#include <iostream>
#include "Car.h"
#include "FuelTank.h"
#include "Battery.h"
using namespace std;

class HMI
{
public:
    HMI();
    ~HMI();
    void showInfor(Car& car);
};

#endif // HMI_H

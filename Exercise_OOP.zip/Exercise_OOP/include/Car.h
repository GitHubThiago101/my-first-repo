#ifndef CAR_H
#define CAR_H
#include "Controller.h"
#include "Engine.h"
#include <iostream>
using namespace std;

class Car : public EngineDelegate
{
public:
    static int counter;
    int getInforPercent;
    int getInforPercentChanged;
    Gear getInforGear;
    int getInforFuel;
    int getInforBattery;

    Car();
//        void startCar();&
    void getController(Car&, Gear, int);
    Controller* controlLight();

    virtual ~Car();
    Car(const Car& other);
    Car& operator=(const Car& other);

    void printCount(void);
    void runThisCar(Gear, int) override;

protected:
//        int percent;
//        Gear gear;

private:
//        Engine *engine;
    Controller *controller;
};

#endif // CAR_H







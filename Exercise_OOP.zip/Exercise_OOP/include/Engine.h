#ifndef ENGINE_H
#define ENGINE_H
#include "Controller.h"

class EngineDelegate{
public:
    virtual void runThisCar(Gear, int) = 0;
};


class Engine : public ControllerDelegate{
public:

    void didChangeGear(Gear) override;
    void didStepOnAccelerator(int) override;

    Engine();
    string stateGear;

    virtual ~Engine();
    Engine(const Engine& other);
    Engine& operator=(const Engine& other);
    void setDelegate(EngineDelegate&);

protected:

private:
    EngineDelegate *delegateCar;
    Gear currentG;
};

#endif // ENGINE_H

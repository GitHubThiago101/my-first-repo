#ifndef FUELTANK_H
#define FUELTANK_H
#include <iostream>
#include <Controller.h>
using namespace std;

class Car;

class FuelTank
{
public:
    FuelTank();
    ~FuelTank();
    void setFuel(int setF);

    int getFuel();

    void consumeFuel(Car& car, int fuel);

private:
    int fuel;
};

#endif // FUELTANK_H

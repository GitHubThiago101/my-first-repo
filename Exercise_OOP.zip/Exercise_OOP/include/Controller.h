#ifndef CONTROLLER_H
#define CONTROLLER_H
#include <iostream>

using namespace std;


enum Gear {
    N,
    D,
    R,
    L1,
    L2
};

class ControllerBattery
{
public:
    virtual void didTurnLight() = 0;
};

class ControllerDelegate{
    public:
        virtual void didStepOnAccelerator(int) = 0;
        virtual void didChangeGear(Gear) = 0;


};

class Controller
{
    public:

        void changeGear(Gear);
        void stepOnAccelerator(int);
        void turnLight(string);

        Controller();
        virtual ~Controller();
        Controller(const Controller& other);
        Controller& operator=(const Controller& other);

        void setDelegate(ControllerDelegate&);
        void setController(ControllerBattery&);

    protected:

    private:
        Gear gear;
        int percent;
        ControllerDelegate *delegate;
        ControllerBattery *controllight;
};

#endif // CONTROLLER_H

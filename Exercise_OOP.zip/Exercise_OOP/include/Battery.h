#ifndef BATTERY_H
#define BATTERY_H
#include "Car.h"
#include <iostream>
using namespace std;



class Battery
{
public:
    Battery();
    ~Battery();
    int getInforEnergy;
    void setBattery(int setB);

    int getEnergy();

    void chargeEnergy(Car& car, int energy);

private:
    int energy;
};

#endif // BATTERY_H
